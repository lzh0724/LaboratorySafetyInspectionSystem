// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "cslg-sys-4gwkot7s23b09200"
}) // 使用当前云环境
const db = cloud.database();

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  let type = event.type
  let infolist = event.infolist
  let photolist = event.photolist
  console.log(event);
  let isCreate = "未赋值"
  //若填写了名称，则进行更新

  await db.collection('report-list').where({
    infolist: infolist,
    photolist: photolist
  }).update({
    data: {
      type: type
    }
  }).then(res => {
    console.log(res);
    //将更新结果赋值到变量
    isCreate = res.stats.updated
  })


  return {
    event
  }
}