const cloud = require('wx-server-sdk');

cloud.init({
  env: "cslg-sys-4gwkot7s23b09200"
});
const db = cloud.database();

// 获取轮播图列表云函数入口函数
exports.main = async (event, context) => {
  // 获取基础信息
  const wxContext = cloud.getWXContext();
  let reportList = []
  let type = event.type
  if (type) {
    reportList = await db.collection("report-list").where({
      type: type
    }).get()
  } else {
    reportList = await db.collection("report-list").get()
  }

  //   console.log(swiperList,"swiperListswiperList");
  return reportList;
};