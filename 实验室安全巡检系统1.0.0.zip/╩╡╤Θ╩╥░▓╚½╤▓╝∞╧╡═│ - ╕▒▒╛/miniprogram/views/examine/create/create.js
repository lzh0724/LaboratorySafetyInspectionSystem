// views/examine/create/create.js
const app = getApp().globalData

Page({

  /**
   * 页面的初始数据
   */
  data: {
    createReportList: [{
        key: "time",
        title: "时间",
        value: ""
      },
      {
        key: "local",
        title: "地点",
        value: ""
      },
      {
        key: "state",
        title: "情况",
        value: ""
      },
      {
        key: "person",
        title: "检查人",
        value: ""
      },
    ],
    reportPhotoList: [],
    rewordPhotoList: [],
    photoUrlList: []
  },
  //选择图片，并将图片信息赋值给数组
  afterRead(event) {
    let that = this
    console.log(event);
    let list = that.data.reportPhotoList
    let file = event.detail.file
    file.deletable = true
    list.push(file)
    that.setData({
      reportPhotoList: list
    })
  },
  //删除已选择的图片
  deletePhoto(e) {
    let that = this
    console.log(e.detail.index);
    let list = that.data.reportPhotoList
    list.splice(e.detail.index, 1)
    that.setData({
      reportPhotoList: list
    })
  },
  //上传文件
  uploadFilePromise(fileName, chooseResult) {
    return wx.cloud.uploadFile({
      cloudPath: fileName,
      filePath: chooseResult.url
    });
  },
  //上传图片到存储
  uploadToCloud(list) {
    // wx.cloud.init();
    let fileList = []
    fileList = list
    console.log(list);
    //上传文件列表，并接收返回的列表
    const uploadTasks = fileList.map((file, index) => this.uploadFilePromise(`${app.openId}-${this.data.createReportList[0].value}-${this.data.createReportList[1].value}-photo-${index}.png`, file));
    Promise.all(uploadTasks)
      .then(data => {
        let list = []
        //将得到的cloud路径赋值给信息列表
        const newFileList = data.map(item => ({
          url: item.fileID
        }));
        list.push(...newFileList)
        this.setData({
          photoCloudPathList: list,
          reportPhotoList: newFileList,
        });
        console.log(this.data.photoCloudPathList);
        //获取cloud路径返回的http路径
        this.getUploadFileUrl(this.data.photoCloudPathList)

      })
      .catch(e => {
        wx.showToast({
          title: '上传失败',
          icon: 'none'
        });
        console.log(e);
      });
  },
  //点击添加按钮
  async addDetailsInfo() {
    let that = this;
    await that.uploadToCloud(that.data.reportPhotoList);
  },
  //获取上传到存储的文件的url列表
  getUploadFileUrl(list) {
    let that = this
    console.log(list);
    let newlist = []
    list.map(item => {
      newlist.push(item.url)
    })
    wx.cloud.callFunction({
      name: 'getFileUrl',
      data: {
        fileList: newlist
      },
      complete: res => {
        console.log(res.result.fileList, "调用云函数");
        //将返回的url的列表，赋值给photoUrlList
        that.setData({
          photoUrlList: res.result.fileList
        })
        console.log(that.data.photoUrlList);
        //获取结束后，上传信息
        that.createReport(that.data.createReportList,that.data.photoUrlList);
      },
      success: res => {

      }
    })
  },
  //将数据上传到数据库
  createReport(createReportList,photoUrlList) {
    let that = this
    wx.cloud.callFunction({
      name: 'createReport',
      data: {
        infolist: createReportList,
        photolist: photoUrlList,
        openid:app.openId,
        type:"wait"
      },
      complete: res => {
        console.log(res.result, "调用上传云函数");
      },
      success: res => {
        wx.showToast({
          title: '上传成功',
          icon: 'none'
        });
        let list = that.data.createReportList
        //上传数据成功后，将数据清除
        list.map(item=>{
          item.value = ""
        })
        console.log(list);
        //清除完成
        that.setData({
          createReportList:list,
          reportPhotoList:[]
        })
      }
    })
  },
  //输入时间地点等信息
  ondetailsInfoListChange(e){
    // console.log(e.target.dataset.index);
    let that = this
    let index= e.target.dataset.index
    let list = []
    list = that.data.createReportList
    list[index].value = e.detail
    that.setData({
      createReportList:list
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})