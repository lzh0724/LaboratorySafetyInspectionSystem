// views/mine/work/work.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isWork:false,
    Searchvalue:"",
    showReportList:[],
    standbyReportList:[],
  },

  async getReportList(type){
    let that = this
    let calltype
    if (type) {
      calltype = type
    }
    await wx.cloud.callFunction({
      name: 'getReportList',
      data:{
        type:calltype
      },
      complete: res => {
        console.log(res.result.data, "调用云函数");
      },
      success: res => {
        that.setData({
          showReportList:res.result.data,
          standbyReportList:res.result.data
        })
      }
    })
  },
  onBindDateSearch(e){
    console.log(e.detail);
    let key = e.detail;
    let that = this;
    that.setData({
      showReportList:that.data.standbyReportList,
      Searchvalue:key
    })
    if (e.detail !== "") {
      let list = [];
      let newlist = [];
      list = that.data.showReportList;
      list.map((item,index)=>{
        let newinfolist = []
        newinfolist = item.infolist
        let flag = false
        newinfolist.map(element=>{
          if (element.value.indexOf(key)!==-1) {
            flag = true
          }
        })
        if(flag)
        {
          newlist.push(list[index])
        }
      })
      that.setData({
        showReportList:newlist
      })
    }
  },
   async updataReport(infolist,photolist,type){
    let that= this
    await wx.cloud.callFunction({
      name: 'updataReport',
      data:{
        infolist:infolist,
        photolist:photolist,
        type:type
      },
      complete: res => {
        console.log(res.result.data, "调用更新云函数");
      },
      success: res => {
      that.getReportList("wait")
        wx.showToast({
          title: '处理成功',
          icon: 'success',
          duration: 2000
        })
      }
    })
  },
  manageButton(e){
    let that = this
    wx.showToast({ title: '处理中', icon: 'loading' });
    console.log(e);
    let infolist = e.currentTarget.dataset.infolist
    let photolist = e.currentTarget.dataset.photolist
    let type = e.currentTarget.dataset.type
    that.updataReport(infolist,photolist,type)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options.title);
    this.setData({
      key:options.title
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that = this 
    switch (that.data.key) {
      case "待审批":
        that.getReportList("wait")
        that.setData({
          isWork:true
        })
        break;
      case "已通过":
        that.getReportList("pass")
        break;
      case "未通过":
        that.getReportList("refuse")
        break;
      case "全部":
        that.getReportList()
        break;
    
      default:
        break;
    }
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})