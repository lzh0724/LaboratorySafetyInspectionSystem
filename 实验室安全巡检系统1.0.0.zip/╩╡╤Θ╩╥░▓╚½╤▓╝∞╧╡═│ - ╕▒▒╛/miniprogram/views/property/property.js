// views/property/property.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Searchvalue:"",
    showReportList:[],
    standbyReportList:[],
  },
  //调用云函数，获取报告列表并赋值到本地
   async getReportList(){
    let that = this
    await wx.cloud.callFunction({
      name: 'getReportList',
      data:{
        type:"pass"
      },
      complete: res => {
        console.log(res.result, "调用云函数");
      },
      success: res => {
        that.setData({
          showReportList:res.result.data,
          standbyReportList:res.result.data
        })
      }
    })
  },
  //监测搜索框的值的变化
  onBindDateSearch(e){
    console.log(e.detail);
    let key = e.detail;
    let that = this;
    that.setData({
      showReportList:that.data.standbyReportList,
      Searchvalue:key
    })
    if (e.detail !== "") {
      let list = [];
      let newlist = [];
      list = that.data.showReportList;
      list.map((item,index)=>{
        let newinfolist = []
        newinfolist = item.infolist
        let flag = false
        newinfolist.map(element=>{
          if (element.value.indexOf(key)!==-1) {
            flag = true
          }
        })
        if(flag)
        {
          newlist.push(list[index])
        }
      })
      that.setData({
        showReportList:newlist
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let that = this 
    that.getReportList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})